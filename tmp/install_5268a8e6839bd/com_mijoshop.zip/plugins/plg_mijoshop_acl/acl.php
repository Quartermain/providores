<?php
/*
* @package		MijoShop
* @copyright	2009-2012 Mijosoft LLC, mijosoft.com
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No Permission
defined('_JEXEC') or die ('Restricted access');

jimport('joomla.plugin.plugin');

class plgMijoshopAcl extends JPlugin {

	public function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		
		$file = JPATH_SITE.'/components/com_mijoshop/mijoshop/mijoshop.php';
		
		if (file_exists($file)) {
			require_once($file);
		}
	}
	
	public function getViewHtml($integration){

        if(empty($integration['acl_add'])){
            $integration['acl_add'] = "";
        }

        if(empty($integration['acl_remove'])){
            $integration['acl_remove'] = "";
        }
	
		$html  = '<fieldset style="width:47%; float: left; margin: 5px;">';
        $html .=    '<legend>Joomla ACL</legend>';
        $html .=        '<table class="form">';
        $html .=            '<tr>';
        $html .=                '<td><strong>Add to Groups</strong></br> </br> 5=8:7:6,3=3:4 </br>(orderstatusid=groupid:groupid)</td>';
        $html .=                '<td><textarea name="content[acl][add]" style="width:350px; height:60px">'. $integration['acl_add'] .'</textarea></td>';
        $html .=            '</tr>';
        $html .=            '<tr>';
        $html .=                '<td><strong>Remove from Groups</strong></br> </br> 5=8:7:6,3=3:4 </br>(orderstatusid=groupid:groupid) </td>';
        $html .=                '<td><textarea name="content[acl][remove]" style="width:350px; height:60px">'. $integration['acl_remove']  .'</textarea></td>';
        $html .=            '</tr>';
        $html .=        '</table>';
        $html .=    '</fieldset>';
		
		return $html;
	}

    public function onMijoshopBeforeOrderStatusUpdate($data, $order_id, $order_status_id, $notify) {
        $results = self::_updateUserGroups($data, $order_id, $order_status_id, $notify);
    }

    public function onMijoshopBeforeOrderConfirm($data, &$order_id, &$order_status_id, &$notify) {
        $results = self::_updateUserGroups($data, $order_id, $order_status_id, $notify);
    }

    private function _updateUserGroups($data, $order_id, $order_status_id, $notify){
        $db = JFactory::getDBO();
        $db->setQuery("SELECT * FROM #__mijoshop_order_product WHERE order_id = " . $order_id);
        $order_products = $db->loadAssocList();
		
		if (empty($order_products)) {
			return;
		}

        foreach($order_products as $order_product)
        {
            $order_product =  MijoShop::get('base')->getIntegrations($order_product['product_id']);
            if (isset($order_product->acl)) {
                $tmp = $order_product->acl;

                if(isset($tmp->add) && isset($tmp->add->$order_status_id)){
                    $groups = $tmp->add->$order_status_id;
                    self::_addUserToGroup($order_id, $groups);
                }

                if(isset($tmp->remove) && isset($tmp->remove->$order_status_id)){
                    $groups = $tmp->remove->$order_status_id;
                    self::_removeUserFromGroup($order_id, $groups);
                }
            }
        }
    }

    private function _addUserToGroup( $order_id, $groups) {

        $customer_info = MijoShop::get('db')->run("SELECT customer_id, email FROM #__mijoshop_order WHERE order_id = {$order_id}", 'loadRow');

        $user_id = MijoShop::get('user')->getJUserIdFromOCustomer($customer_info[0], $customer_info[1]);

        if(empty($user_id))
        {
            return;
        }

        foreach ($groups as $group) {
            JUserHelper::addUserToGroup($user_id, $group);
        }
    }

    private function _removeUserFromGroup( $order_id, $groups) {

        $customer_info = MijoShop::get('db')->run("SELECT customer_id, email FROM #__mijoshop_order WHERE order_id = {$order_id}", 'loadRow');

        $user_id = MijoShop::get('user')->getJUserIdFromOCustomer($customer_info[0], $customer_info[1]);

        if(empty($user_id))
        {
            return;
        }

        foreach ($groups as $group) {
            JUserHelper::removeUserFromGroup($user_id, $group);
        }
    }
}