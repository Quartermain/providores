<?php
/**
* @package		MijoShop
* @copyright	2009-2013 Mijosoft LLC, mijosoft.com
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

defined('_JEXEC') or die('Restricted access');

// Import Libraries
jimport('joomla.application.helper');
jimport('joomla.filesystem.file');
jimport('joomla.installer.installer');

class MijoshopThemesInstallerScript {
	
	public function preflight($type, $parent) {
		if (!file_exists(JPATH_ROOT.'/components/com_mijoshop/mijoshop/mijoshop.php')) {
			JLog::add('MijoShop component (com_mijoshop) is not installed. Please, install it first.', JLog::ERROR, 'jerror');
			
			return false;
		}
	}
	
	public function postflight($type, $parent) {
        $src = $parent->getParent()->getPath('source');
		
		$_themes_zip = $src.'/themes.zip';
		$_themes_gzip = $src.'/themes.tar.gz';

		$_dir = JPath::clean(JPATH_ROOT.'/components/com_mijoshop/opencart');

		if (JFile::exists($_themes_zip)) {
			$_file = JPath::clean($_themes_zip);
		}
		else if (JFile::exists($_themes_gzip)) {
			$_file = JPath::clean($_themes_gzip);
		}

		JArchive::extract($_file, $_dir);
		
		if (JFile::exists(JPATH_ROOT.'/components/com_mijoshop/themes.zip')) {
			JFile::delete(JPATH_ROOT.'/components/com_mijoshop/themes.zip');
		}
		
		if (JFile::exists(JPATH_ROOT.'/components/com_mijoshop/mijoshopthemes.xml')) {
			JFile::delete(JPATH_ROOT.'/components/com_mijoshop/mijoshopthemes.xml');
		}
		
		if (JFile::exists(JPATH_ROOT.'/components/com_mijoshop/script.php')) {
			JFile::delete(JPATH_ROOT.'/components/com_mijoshop/script.php');
		}
	}
}